import pygame
import math
import random
import asyncio

pygame.init()

WIDTH = 1000
HEIGHT = 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Physics Asteroids & AI")
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GRAY = (100, 100, 100)
BLACK = (0, 0, 0)

class Player:
    def __init__(self):
        self.position = pygame.Vector2(WIDTH / 2, HEIGHT / 2)
        self.velocity = pygame.Vector2(0, 0)
        self.acceleration = pygame.Vector2(0, 0)
        self.angle = 90
        self.rotation_speed = 4.5
        self.thrust = 0.25
        self.drag = 0.92
        self.max_speed = 6
        self.is_thrusting = False
        self.radius = 16

    def update(self, keys):
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.angle += self.rotation_speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.angle -= self.rotation_speed

        radians = math.radians(self.angle)
        forward = pygame.Vector2(math.cos(radians), -math.sin(radians))

        self.acceleration = pygame.Vector2(0, 0)
        self.is_thrusting = False

        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.acceleration = forward * self.thrust
            self.is_thrusting = True

        self.velocity += self.acceleration
        self.velocity *= self.drag

        if self.velocity.length() > self.max_speed:
            self.velocity.scale_to_length(self.max_speed)

        self.position += self.velocity

        if self.position.x > WIDTH:
            self.position.x = WIDTH
            self.velocity.x = 0
        if self.position.x < 0:
            self.position.x = 0
            self.velocity.x = 0
        if self.position.y > HEIGHT:
            self.position.y = HEIGHT
            self.velocity.y = 0
        if self.position.y < 0:
            self.position.y = 0
            self.velocity.y = 0

    def draw(self, surface):
        radians = math.radians(self.angle)
        forward = pygame.Vector2(math.cos(radians), -math.sin(radians))
        left = forward.rotate(140)
        right = forward.rotate(-140)

        p1 = self.position + forward * 22
        p2 = self.position + left * 16
        p3 = self.position + right * 16

        pygame.draw.polygon(surface, WHITE, [p1, p2, p3], 2)

        if self.is_thrusting:
            back = self.position - forward * 18
            pygame.draw.circle(surface, YELLOW, (int(back.x), int(back.y)), 5)

class Missile:
    def __init__(self, position, target, color=YELLOW):
        self.position = pygame.Vector2(position)
        direction = target - self.position
        if direction.length() > 0:
            direction = direction.normalize()
        else:
            direction = pygame.Vector2(0, -1)
        self.speed = 5
        self.velocity = direction * self.speed
        self.color = color

    def update(self):
        self.position += self.velocity

    def draw(self, surface):
        pygame.draw.circle(surface, self.color, (int(self.position.x), int(self.position.y)), 3)

class Asteroid:
    def __init__(self):
        self.position = pygame.Vector2(random.randint(0, WIDTH), random.randint(0, HEIGHT))
        self.velocity = pygame.Vector2(random.uniform(-1.2, 1.2), random.uniform(-1.2, 1.2))
        if self.velocity.length() == 0:
            self.velocity = pygame.Vector2(1, 0)
        self.radius = random.randint(20, 50)
        self.mass = self.radius

    def update(self):
        self.position += self.velocity
        if self.position.x > WIDTH + self.radius:
            self.position.x = -self.radius
        elif self.position.x < -self.radius:
            self.position.x = WIDTH + self.radius
        if self.position.y > HEIGHT + self.radius:
            self.position.y = -self.radius
        elif self.position.y < -self.radius:
            self.position.y = HEIGHT + self.radius

    def draw(self, surface):
        pygame.draw.circle(surface, GRAY, (int(self.position.x), int(self.position.y)), self.radius, 2)

class Enemy:
    def __init__(self):
        self.position = pygame.Vector2(WIDTH / 4, HEIGHT / 4)
        self.patrol_velocity = pygame.Vector2(1.5, 1.0)
        self.angle = 0
        self.state = "PATROL"
        self.detection_range = 300
        self.fov_threshold = 0.7
        self.last_shot_time = 0
        self.shoot_delay = 1000
        self.radius = 20

    def update(self, target_pos, current_time):
        should_shoot = False
        radians = math.radians(self.angle)
        forward = pygame.Vector2(math.cos(radians), -math.sin(radians))
        
        to_player = target_pos - self.position
        distance = to_player.length()
        
        if distance > 0:
            to_player = to_player.normalize()
            dot = forward.dot(to_player)
            
            if distance < self.detection_range and dot > self.fov_threshold:
                self.state = "ATTACK"
                if current_time - self.last_shot_time > self.shoot_delay:
                    should_shoot = True
                    self.last_shot_time = current_time
            else:
                self.state = "PATROL"
        
        self.position += self.patrol_velocity
        self.angle += 1.5
            
        if self.position.x > WIDTH:
            self.position.x = WIDTH
            self.patrol_velocity.x *= -1
        elif self.position.x < 0:
            self.position.x = 0
            self.patrol_velocity.x *= -1
            
        if self.position.y > HEIGHT:
            self.position.y = HEIGHT
            self.patrol_velocity.y *= -1
        elif self.position.y < 0:
            self.position.y = 0
            self.patrol_velocity.y *= -1
        
        if self.angle >= 360:
            self.angle -= 360

        return should_shoot

    def draw(self, surface):
        color = RED if self.state == "ATTACK" else WHITE
        
        radians = math.radians(self.angle)
        forward = pygame.Vector2(math.cos(radians), -math.sin(radians))
        left = forward.rotate(140)
        right = forward.rotate(-140)

        p1 = self.position + forward * 20
        p2 = self.position + left * 15
        p3 = self.position + right * 15

        pygame.draw.polygon(surface, color, [p1, p2, p3], 2)
        pygame.draw.circle(surface, GRAY, (int(self.position.x), int(self.position.y)), self.detection_range, 1)
        
        end_point = self.position + forward * 100
        pygame.draw.line(surface, RED, self.position, end_point, 2)

        font = pygame.font.Font(None, 24)
        text = font.render(f"Enemy: {self.state}", True, color)
        surface.blit(text, (self.position.x - 50, self.position.y - 40))

def resolve_collisions(asteroids):
    for i in range(len(asteroids)):
        for j in range(i + 1, len(asteroids)):
            a = asteroids[i]
            b = asteroids[j]
            
            dist_vec = a.position - b.position
            dist = dist_vec.length()
            
            if dist < a.radius + b.radius:
                if dist == 0:
                    dist_vec = pygame.Vector2(1, 0)
                    dist = 1
                
                normal = dist_vec.normalize()
                rel_vel = a.velocity - b.velocity
                vel_along_normal = rel_vel.dot(normal)
                
                if vel_along_normal > 0:
                    continue
                
                restitution = 1.0
                j_impulse = -(1 + restitution) * vel_along_normal
                j_impulse /= (1 / a.mass + 1 / b.mass)
                
                impulse = normal * j_impulse
                
                a.velocity += impulse / a.mass
                b.velocity -= impulse / b.mass
                
                overlap = (a.radius + b.radius - dist) / 2.0
                a.position += normal * (overlap + 0.1)
                b.position -= normal * (overlap + 0.1)

async def main():
    player = Player()
    missiles = []
    enemy_missiles = []
    asteroids = [Asteroid() for _ in range(8)]
    enemy = Enemy()
    score = 0
    font = pygame.font.Font(None, 36)
    large_font = pygame.font.Font(None, 72)
    game_over = False

    running = True
    while running:
        current_time = pygame.time.get_ticks()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_over:
                    player = Player()
                    missiles = []
                    enemy_missiles = []
                    asteroids = [Asteroid() for _ in range(8)]
                    enemy = Enemy()
                    score = 0
                    game_over = False
            elif event.type == pygame.MOUSEBUTTONDOWN and not game_over:
                target = pygame.Vector2(event.pos)
                
                radians = math.radians(player.angle)
                forward = pygame.Vector2(math.cos(radians), -math.sin(radians))
                
                tip_position = player.position + forward * 22
                
                missiles.append(Missile(tip_position, target, YELLOW))

        if not game_over:
            keys = pygame.key.get_pressed()
            player.update(keys)
            
            if enemy.update(player.position, current_time):
                enemy_missiles.append(Missile(enemy.position, player.position, RED))
                
            resolve_collisions(asteroids)

            for ast in asteroids:
                ast.update()
                if player.position.distance_to(ast.position) < player.radius + ast.radius:
                    game_over = True

            if player.position.distance_to(enemy.position) < player.radius + enemy.radius:
                game_over = True

            for missile in enemy_missiles[:]:
                missile.update()
                if player.position.distance_to(missile.position) < player.radius:
                    game_over = True
                
                missile_destroyed = False
                for ast in asteroids:
                    if missile.position.distance_to(ast.position) < ast.radius:
                        missile_destroyed = True
                        break
                        
                if missile_destroyed or (missile.position.x < 0 or missile.position.x > WIDTH or 
                                         missile.position.y < 0 or missile.position.y > HEIGHT):
                    if missile in enemy_missiles:
                        enemy_missiles.remove(missile)

            for missile in missiles[:]:
                missile.update()
                missile_destroyed = False
                
                for ast in asteroids[:]:
                    if missile.position.distance_to(ast.position) < ast.radius:
                        asteroids.remove(ast)
                        if missile in missiles:
                            missiles.remove(missile)
                        missile_destroyed = True
                        score += 100
                        asteroids.append(Asteroid())
                        break
                
                if not missile_destroyed:
                    if (missile.position.x < 0 or missile.position.x > WIDTH or 
                        missile.position.y < 0 or missile.position.y > HEIGHT):
                        if missile in missiles:
                            missiles.remove(missile)

        screen.fill(BLACK)
        
        if not game_over:
            player.draw(screen)
            
        enemy.draw(screen)
        
        for ast in asteroids:
            ast.draw(screen)
            
        for missile in missiles:
            missile.draw(screen)
            
        for missile in enemy_missiles:
            missile.draw(screen)

        score_surface = font.render(f"Score: {score}", True, WHITE)
        screen.blit(score_surface, (20, 20))

        if game_over:
            go_text = large_font.render("GAME OVER", True, RED)
            restart_text = font.render("Press R to Restart", True, WHITE)
            screen.blit(go_text, (WIDTH//2 - go_text.get_width()//2, HEIGHT//2 - 50))
            screen.blit(restart_text, (WIDTH//2 - restart_text.get_width()//2, HEIGHT//2 + 20))

        pygame.display.flip()
        await asyncio.sleep(0)
        clock.tick(60)

    pygame.quit()

if __name__ == "__main__":
    asyncio.run(main())